using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Asistencia.Domain.Entities
{
    public class AsistenciaDTO
    {
        public string MAC {get; set;}
        public string CodigoQR {get; set;}
    }
}