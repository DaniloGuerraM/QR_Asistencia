using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Asistencia.Domain.Entities
{
    public class AlumnoDTO
    {
        public int DNI {get; set;}
        public string MAC {get; set;}
    }
}